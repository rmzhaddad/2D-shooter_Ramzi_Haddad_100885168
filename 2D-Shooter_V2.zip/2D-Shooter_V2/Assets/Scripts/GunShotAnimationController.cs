﻿using UnityEngine;
using System.Collections;

public class GunShotAnimationController : MonoBehaviour {



	void end()
	{
		Destroy (gameObject);
	}
}
